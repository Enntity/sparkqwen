#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-only
"""Owned remote worker: one frozen request with immediate raw HTTP preservation."""
import argparse,base64,hashlib,json,pathlib,subprocess,time,urllib.request,urllib.error
if not __debug__:raise RuntimeError('assertions must remain enabled')
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def perform(a,root):
 body=(root/'case50-request.body').read_bytes();assert hashlib.sha256(body).hexdigest()==a.request_sha
 assert a.mode in ('on','off')
 def identity():
  x=json.loads(subprocess.check_output(['docker','inspect',a.cid],timeout=20))[0];assert x['Id']==a.cid and x['Image']==a.image and x['State']['Running'];return {'container_id':a.cid,'image_id':a.image,'started_at':x['State']['StartedAt']}
 def logs():
  b=subprocess.check_output(['docker','logs',a.cid],stderr=subprocess.STDOUT,timeout=20);assert len(b)<=8*1024*1024;return b.decode()
 def metrics():
  with urllib.request.urlopen('http://127.0.0.1:8893/metrics',timeout=10) as r:return r.read().decode()
 before=identity();log_before=logs();metric_before=metrics()
 save(root/'case50-before.json',{'identity':before,'native_log':log_before,'metrics':metric_before})
 active=[float(x.split()[1]) for x in metric_before.splitlines() if x.startswith('atlas_requests_active ')]
 total=[float(x.split()[1]) for x in metric_before.splitlines() if x.startswith('atlas_requests_total ')]
 assert active==[0] or (a.mode=='off' and active==[] and total==[] and 'Done:' not in log_before),'request already active or first-request scope unproven'
 assert identity()==before
 start=time.time_ns();request=urllib.request.Request('http://127.0.0.1:8893/v1/chat/completions',body,{'Content-Type':'application/json'})
 try:r=urllib.request.urlopen(request,timeout=600)
 except urllib.error.HTTPError as error:r=error
 with r:
  status=r.status;headers=dict(r.headers)
  save(root/'case50-http.json',{'status':status,'headers':headers,'request_sha256':a.request_sha,'started_ns':start})
  with (root/'case50-response.body').open('xb') as f:
   count=0
   while True:
    chunk=r.read1(4096)
    if not chunk:break
    f.write(chunk);f.flush();count+=len(chunk);assert count<=8*1024*1024,'response exceeds bounded diagnostic'
 finish=time.time_ns();response=(root/'case50-response.body').read_bytes()
 # Raw response is already in the owned directory before any post-response check.
 for i in range(10):
  log_after=logs();assert identity()==before and log_after.startswith(log_before)
  if 'Done:' in log_after[len(log_before):]:break
  time.sleep(.2)
 result={'before':before,'after':identity(),'native_before':log_before,'native_after':log_after,'metrics_before':metric_before,'metrics_after':metrics(),'status':status,'headers':headers,'response_b64':base64.b64encode(response).decode(),'request_sha256':a.request_sha,'started_ns':start,'finished_ns':finish}
 save(root/'case50-worker-receipt.json',result);print(json.dumps(result))
def main():
 p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('cid');p.add_argument('image');p.add_argument('request_sha');p.add_argument('mode',choices=['on','off']);a=p.parse_args();root=pathlib.Path(a.root)
 try:perform(a,root)
 except BaseException as error:
  save(root/'case50-worker-error.json',{'error':repr(error)});raise
if __name__=='__main__':main()
