#!/usr/bin/env python3
"""The existing five-prose C1 probe, with per-request log evidence and paired salts."""
import datetime, hashlib, json, os, pathlib, re, statistics, sys, time
from run import cmd, dump
c=json.loads(pathlib.Path(sys.argv[1]).read_text()); out=pathlib.Path(sys.argv[2]); node=c['nodes'][0]
os.environ.update(BENCH_URL=c['url'],BENCH_MODEL=c['model'])
sys.path.insert(0,str(pathlib.Path(__file__).parent/'harnesses/glm'))
import tp4bench
import step_trace_summary

def logs():
    r=cmd(node,['docker','logs',node['container']]); return r.stdout+r.stderr

tp4bench.stream('Say hi.',8)
prompt,cap=tp4bench.WORK['prose']; rows=[]
for i in range(5):
    before=logs()
    tag=hashlib.sha256(f"{c['comparison_id']}/step/{i}".encode()).hexdigest()[:12]
    sent,first,end,usage,text=tp4bench.stream(f'Run tag {tag}.\n\n'+prompt,cap)
    after=logs(); assert after.startswith(before), 'Log rotation/reordering prevents exact request attribution'
    delta=after[len(before):]; logfile=out/f'step-request-{i}.log'; logfile.write_bytes(delta)
    clean=re.sub(r'\x1b\[[0-9;]*m','',delta.decode())
    done=re.findall(r'Done: (\d+) tokens[^\n]*?([0-9.]+) tok/s[^\n]*?tok_step=([0-9.]+)',clean)
    assert len(done)==1, 'Expected exactly one attributable Done line'
    tokens,tps,tokstep=map(float,done[0]); assert tokens==usage['completion_tokens'] and tps>0
    row={'rep':i,'prompt_sha256':hashlib.sha256((f'Run tag {tag}.\n\n'+prompt).encode()).hexdigest(),
         'tokens':tokens,'accepted_tok_s_server':tps,'tokens_per_verify_step_server':tokstep,
         'derived_step_ms':1000*tokstep/tps,'formula':'1000 * tok_step / server_tok_s',
         'client_tok_s':tokens/(end-first),'ttft_s':first-sent}
    steps=step_trace_summary.parse([str(logfile)])
    if c.get('step_trace_diagnostic',False):
        steady=[s for s in steps if s['kind']=='mtp' and s['n']==1 and s['seqs'] and s['seqs'][0][1]>=16]
        assert steady, 'Trace-enabled diagnostic has no steady C1 MTP records'
        row['trace_scheduler_decode_tick_ms']={'count':len(steady),'median':statistics.median(s['dur']/1000 for s in steady),
             'definition':'(dur - pf) / 1000 from MTP STEP; n=1, kind=mtp, generated>=16; includes host dispatch, not a GPU kernel timer'}
    else: assert not steps, 'Trace changes published conditions; select separate diagnostic config'
    rows.append(row)
dump(out/'step-probe.json',{'rows':rows,'median_derived_step_ms':statistics.median(r['derived_step_ms'] for r in rows),
     'goal_ms':26,'goal_is_approximate':True,'trace_diagnostic':c.get('step_trace_diagnostic',False),
     'warning':'Derived chain step cost and accepted-token throughput are separate measurements.'})
