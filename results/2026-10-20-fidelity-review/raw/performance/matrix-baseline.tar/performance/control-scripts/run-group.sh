#!/usr/bin/env bash
# Coordinator owns LLooM reservation, exact model launch, fresh caches, and routes.
set -Eeuo pipefail
[[ $# == 3 && $1 == --uncap ]] || { echo 'Usage: run-group.sh --uncap CONFIG.json NEW_RECEIPT_DIR' >&2; exit 2; }
root=$(cd -- "$(dirname -- "$0")" && pwd)
config=$2
out=$3
worker=
python3 "$root/run.py" prepare "$config" "$out"
restore() {
  rc=$?
  trap - EXIT INT TERM
  # Stop the Python owner first; its finally block stops the harness process group.
  if [[ -n $worker ]] && kill -0 "$worker" 2>/dev/null; then
    kill -TERM "$worker" 2>/dev/null || true
    wait "$worker" 2>/dev/null || true
  fi
  if ! python3 "$root/run.py" restore "$config" "$out"; then
    echo 'CLOCK RESTORATION FAILED; restore the cap services before releasing hardware.' >&2
    exit 1
  fi
  exit "$rc"
}
trap restore EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
python3 "$root/run.py" uncap "$config" "$out"
python3 "$root/run.py" run "$config" "$out" &
worker=$!
wait "$worker"
worker=
