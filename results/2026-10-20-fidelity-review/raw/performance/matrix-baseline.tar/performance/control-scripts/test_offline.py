#!/usr/bin/env python3
"""Offline fixture checks; no HTTP, SSH, Docker, clocks, or inference."""
import importlib.util, io, json, pathlib, tempfile, unittest, types
from unittest import mock
import run
from run import commands, validate_result
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('audit',ROOT/'audit/sitecustomize.py'); audit=importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)
GOOD=b'data: {"choices":[{"finish_reason":"length"}]}\n\ndata: {"choices":[],"usage":{"completion_tokens":4}}\n\ndata: [DONE]\n\n'
class Tests(unittest.TestCase):
    def test_complete_stream(self): self.assertEqual(audit.validate(GOOD,{'max_tokens':4,'min_tokens':4})['usage']['completion_tokens'],4)
    def test_reject_missing_done(self):
        with self.assertRaises(ValueError): audit.validate(GOOD.replace(b'data: [DONE]',b''),{})
    def test_reject_short_forced_output(self):
        with self.assertRaises(ValueError): audit.validate(GOOD,{'max_tokens':5,'ignore_eos':True})
    def test_reject_error_event(self):
        with self.assertRaises(ValueError): audit.validate(b'data: {"error":{"message":"bad"}}\n'+GOOD,{})
    def test_reject_missing_finish(self):
        with self.assertRaises(ValueError): audit.validate(GOOD.replace(b'"length"',b'null'),{})
    def test_all_command_groups(self):
        from run import GROUPS
        for group in GROUPS:
            c={'group':group,'arm':'fixture','url':'http://127.0.0.1:1','model':'fixture','comparison_id':'paired'}
            rows=commands(c,pathlib.Path('/tmp/never-run'))
            self.assertTrue(rows)
            self.assertTrue(all(r['minimum_streams']>0 for r in rows))
    def test_fail_closed_missing_requests(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp); (out/'x.audit.jsonl').write_text('{"ok":true}\n')
            with self.assertRaises(AssertionError): validate_result({'name':'x','minimum_streams':2,'output':None,'kind':'prefill'},out)
    def test_mount_guard_rejects_runtime_overlap(self):
        for dst in ('/','/opt','/opt/atlas','/opt/atlas/','/opt/atlas/serve.py','/opt/atlas/native/lib.so','/opt/atlas/profiles/x.json','/usr','/usr/local/bin','/usr/local/bin/spark'):
            with self.subTest(dst=dst): self.assertTrue(run.mount_overlaps_runtime(dst))
    def test_mount_guard_allows_unrelated_mounts(self):
        for dst in ('/models','/opt/atlas-cache','/opt/other','/usr/local/bin/other','/cache'):
            with self.subTest(dst=dst): self.assertFalse(run.mount_overlaps_runtime(dst))
    def test_inactive_required_on_every_rank(self):
        run.require_inactive([{'clock':'inactive'},{'clock':'inactive'}])
        for records in ([],[{'clock':'inactive'},{'clock':'active'}],[{'clock':'failed'}]):
            with self.assertRaises(AssertionError): run.require_inactive(records)
    def test_post_uncap_clock_receipts(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            def reply(node,argv): return types.SimpleNamespace(stdout=b'inactive\n' if argv[0]=='systemctl' else b'clock evidence')
            with mock.patch.object(run,'cmd',side_effect=reply): run.capture_uncapped_clocks({'nodes':[{'host':'local'},{'host':'peer'}]},out)
            rows=json.loads((out/'post-uncap-clocks.json').read_text())
            self.assertEqual([r['clock'] for r in rows],['inactive','inactive'])
            self.assertTrue(all(r['captured_unix']>0 for r in rows))
            self.assertEqual((out/'post-uncap-rank1/nvidia-smi.txt').read_bytes(),b'clock evidence')
    def test_post_uncap_active_fails_and_keeps_receipt(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp)
            with mock.patch.object(run,'cmd',return_value=types.SimpleNamespace(stdout=b'active\n')):
                with self.assertRaises(AssertionError): run.capture_uncapped_clocks({'nodes':[{'host':'local'}]},out)
            self.assertEqual(json.loads((out/'post-uncap-clocks.json').read_text())[0]['clock'],'active')
    def test_control_hash_archive_and_tamper_rejection(self):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp); (root/'control.py').write_bytes(b'original')
            hashes={'control.py':run.digest(b'original')}
            run.verify_manifest(root,hashes,root/'archive')
            self.assertEqual((root/'archive/control.py').read_bytes(),b'original')
            (root/'control.py').write_bytes(b'changed')
            with self.assertRaises(AssertionError): run.verify_manifest(root,hashes)
    def test_package_rejects_missing_control_hashes(self):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp)
            for name in ('harness-sha256.json','runner-sha256.json'): (root/name).write_text('{}')
            with self.assertRaises(AssertionError): run.verify_package(root)
    def test_after_snapshot_rejects_reactivated_cap(self):
        with tempfile.TemporaryDirectory() as temp:
            out=pathlib.Path(temp); source=b'{}'
            node={'host':'local','container':'rank0','image_id':'image','profile_path':'/opt/atlas/profiles/p.json',
                  'profile_sha256':run.digest(source),'manifest_sha256':run.digest(source),'binary_sha256':'abc'}
            info={'State':{'Running':True,'StartedAt':'start'},'Image':'image','Id':'id','Mounts':[],
                  'Config':{'Env':['SPARKGLM_PROFILE=p']}}
            def reply(n,argv,check=True):
                raw=b''
                if argv[:2]==['docker','inspect']: raw=json.dumps([info]).encode()
                elif 'cat' in argv: raw=source
                elif 'sha256sum' in argv: raw=b'abc  /usr/local/bin/spark'
                elif argv[0]=='systemctl': raw=b'active\n'
                return types.SimpleNamespace(stdout=raw,stderr=b'')
            response=mock.MagicMock(); response.__enter__.return_value.status=200
            response.__enter__.return_value.read.return_value=b'{"data":[{"id":"model"}]}'
            c={'nodes':[node],'group':'glm-main','profile':'p','required_launch_env':{},'url':'http://fixture','model':'model'}
            with mock.patch.object(run,'cmd',side_effect=reply), mock.patch.object(run.urllib.request,'urlopen',return_value=response):
                with self.assertRaisesRegex(AssertionError,'remain inactive'): run.snapshot(c,out,'after')
            self.assertEqual(json.loads((out/'after-identity.json').read_text())[0]['clock'],'active')
if __name__=='__main__': unittest.main()
