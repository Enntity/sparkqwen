// End-of-stream audit without changing prompts, bodies, chunks, or warmup policy.
import { appendFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, options = {}) => {
  const body = JSON.parse(options.body || '{}');
  if (!body.stream) return realFetch(url, options);
  const row = {url: String(url), stream: true, started_unix: Date.now()/1000,
    request_sha256: createHash('sha256').update(options.body).digest('hex')};
  const record = () => appendFileSync(process.env.PERF_AUDIT, JSON.stringify(row)+'\n');
  let response;
  try { response = await realFetch(url, options); if (response.status !== 200) throw Error(`HTTP ${response.status}`); }
  catch (e) { row.ok=false; row.error=String(e); record(); throw e; }
  const parts = [];
  const audited = response.body.pipeThrough(new TransformStream({
    transform(chunk, controller) { parts.push(Buffer.from(chunk)); controller.enqueue(chunk); },
    flush() {
      try {
        let done=false, finishes=[], usage;
        for (const line of Buffer.concat(parts).toString().split(/\r?\n/)) {
          if (!line.startsWith('data:')) continue;
          const data=line.slice(5).trim();
          if (data==='[DONE]') { done=true; continue; }
          const event=JSON.parse(data); if (event.error) throw Error(JSON.stringify(event.error));
          if (event.usage) usage=event.usage;
          finishes.push(...(event.choices || []).map(c=>c.finish_reason).filter(Boolean));
        }
        if (!done || !finishes.length || !(usage?.completion_tokens>0)) throw Error('Missing DONE, finish reason, or positive usage');
        const minimum=Math.max(body.min_tokens || 0, body.ignore_eos ? body.max_tokens : 0);
        if (usage.completion_tokens<minimum || usage.completion_tokens>body.max_tokens) throw Error('Forced output length mismatch');
        Object.assign(row, {ok:true, done, usage, finish_reasons:finishes});
      } catch(e) { row.ok=false; row.error=String(e); throw e; }
      finally { row.ended_unix=Date.now()/1000; record(); }
    }
  }));
  return new Response(audited, {status:response.status, headers:response.headers});
};
