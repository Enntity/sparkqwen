import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
const dir=mkdtempSync(join(tmpdir(),'perf-audit-test-'));
process.env.PERF_AUDIT=join(dir,'audit.jsonl');
let payload='';
globalThis.fetch=async ()=>new Response(payload,{status:200});
await import('./fetch.mjs');
try {
  const good='data: {"choices":[{"finish_reason":"length"}],"usage":{"completion_tokens":4}}\n\ndata: [DONE]\n\n';
  const opts={body:JSON.stringify({stream:true,max_tokens:4,min_tokens:4})};
  payload=good; await (await fetch('fixture',opts)).text();
  payload=good.replace('data: [DONE]',''); await assert.rejects(async()=>await (await fetch('fixture',opts)).text());
  const rows=readFileSync(process.env.PERF_AUDIT,'utf8').trim().split('\n').map(JSON.parse);
  assert.equal(rows.length,2); assert.equal(rows[0].ok,true); assert.equal(rows[1].ok,false);
  console.log('Node audit fixtures passed');
} finally { rmSync(dir,{recursive:true}); }
