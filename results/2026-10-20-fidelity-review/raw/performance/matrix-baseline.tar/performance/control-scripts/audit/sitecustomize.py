"""Loaded only by the runner's child Python processes; original harnesses stay intact."""
import hashlib, json, os, threading, time, urllib.request
_LOCK = threading.Lock()
_REAL = urllib.request.urlopen

def record(row):
    with _LOCK:
        with open(os.environ['PERF_AUDIT'], 'a') as f:
            f.write(json.dumps(row, sort_keys=True) + '\n')

def validate(raw, body):
    done = False; finishes = []; usage = None
    for line in raw.splitlines():
        if not line.startswith(b'data:'): continue
        data = line[5:].strip()
        if data == b'[DONE]': done = True; continue
        event = json.loads(data)
        if event.get('error'): raise ValueError('SSE error: ' + str(event['error']))
        if event.get('usage'): usage = event['usage']
        finishes += [c['finish_reason'] for c in event.get('choices', []) if c.get('finish_reason')]
    if not done or not finishes or not usage or usage.get('completion_tokens', 0) <= 0:
        raise ValueError('Incomplete SSE: DONE, finish reason and positive usage are required')
    n = usage['completion_tokens']; maximum = body.get('max_tokens', body.get('max_completion_tokens'))
    minimum = body.get('min_tokens', 0)
    if body.get('ignore_eos') and maximum: minimum = max(minimum, maximum)
    if n < minimum or (maximum and n > maximum): raise ValueError(f'Output count {n} violates {minimum}..{maximum}')
    return {'usage': usage, 'finish_reasons': finishes, 'done': done}

class Response:
    def __init__(self, response, body, row):
        self.response = response; self.body = body; self.row = row; self.parts = []; self.closed = False
    def __getattr__(self, name): return getattr(self.response, name)
    def __enter__(self): return self
    def __iter__(self): return self
    def __next__(self):
        data = self.readline()
        if not data: raise StopIteration
        return data
    def readline(self, *args):
        data = self.response.readline(*args); self.parts.append(data); return data
    def read(self, *args):
        data = self.response.read(*args); self.parts.append(data); return data
    def close(self, exception=None):
        if self.closed: return
        self.closed = True
        error = exception
        try:
            if error: raise ValueError(str(error))
            self.row.update(validate(b''.join(self.parts), self.body)); self.row['ok'] = True
        except Exception as exc:
            error = exc; self.row.update(ok=False, error=str(exc))
        finally:
            self.row['ended_unix'] = time.time(); record(self.row); self.response.close()
        if error: raise ValueError('Stream completeness audit failed: ' + str(error))
    def __exit__(self, typ, value, tb): self.close(value)

def urlopen(req, *args, **kwargs):
    data = getattr(req, 'data', None)
    try: body = json.loads(data) if data else {}
    except (ValueError, TypeError): body = {}
    if not body.get('stream'): return _REAL(req, *args, **kwargs)
    row = {'url': req.full_url, 'started_unix': time.time(), 'request_sha256': hashlib.sha256(data).hexdigest(),
           'max_tokens': body.get('max_tokens'), 'min_tokens': body.get('min_tokens'), 'stream': True}
    try:
        response = _REAL(req, *args, **kwargs)
        if response.status != 200: raise ValueError(f'HTTP {response.status}')
    except Exception as exc:
        row.update(ok=False, error=str(exc)); record(row); raise
    return Response(response, body, row)

if os.environ.get('PERF_AUDIT'): urllib.request.urlopen = urlopen
