#!/usr/bin/env python3
"""Prepare, verify, and run one published profile group. Never starts a model."""
import argparse, hashlib, json, os, pathlib, posixpath, re, shlex, signal, subprocess, sys, time, urllib.request
ROOT = pathlib.Path(__file__).resolve().parent
H = ROOT / 'harnesses'
GROUPS = {'glm-main': ('8x128k',131072), 'glm-prefill': ('4x512k',524288),
          'qwen-main': ('8x32k',32768), 'qwen-matrix': ('8x262k',262144),
          'glm-pair-extension': ('4x1m',1048576), 'glm-tp4-extension': ('4x1m-tp4',1048576)}
def dump(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def digest(raw): return hashlib.sha256(raw).hexdigest()
CONTROL_FILES = {'run.py','run-group.sh','step_probe.py','audit/sitecustomize.py','audit/fetch.mjs'}
def mount_overlaps_runtime(destination):
    dst=posixpath.normpath(destination)
    def ancestor(parent,child): return parent=='/' or child==parent or child.startswith(parent+'/')
    return ancestor(dst,'/usr/local/bin/spark') or ancestor(dst,'/opt/atlas') or ancestor('/opt/atlas',dst)

def verify_manifest(root,hashes,archive=None):
    for name,expected in hashes.items():
        path=pathlib.PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts, 'Invalid manifest path'
        raw=(root/name).read_bytes()
        assert digest(raw)==expected, 'Package source changed: '+name
        if archive is not None:
            target=archive/name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(raw)

def verify_package(out,archive=False):
    for name in ('harness-sha256.json','runner-sha256.json'):
        hashes=json.loads(((ROOT if archive else out)/name).read_text())
        if name=='runner-sha256.json': assert CONTROL_FILES <= hashes.keys(), 'Missing control script identity'
        verify_manifest(ROOT,hashes,out/'control-scripts' if archive and name=='runner-sha256.json' else None)
        if archive: dump(out/name,hashes)

def require_inactive(records):
    assert records and all(r['clock']=='inactive' for r in records), 'All benchmark clock cap services must remain inactive'

def capture_uncapped_clocks(c,out):
    records=[]
    for i,n in enumerate(c['nodes']):
        p=out/f'post-uncap-rank{i}'; p.mkdir()
        state=cmd(n,['systemctl','show','gpu-clock-cap.service','--property=ActiveState','--value']).stdout
        (p/'clock-service-state.txt').write_bytes(state)
        (p/'nvidia-smi.txt').write_bytes(cmd(n,['nvidia-smi','-q']).stdout)
        records.append({'host':n['host'],'clock':state.decode().strip(),'captured_unix':time.time()})
    dump(out/'post-uncap-clocks.json',records)
    require_inactive(records)

def cmd(node, argv, check=True):
    host = node['host']
    if not re.fullmatch(r'[a-zA-Z0-9_.:@-]+',host): raise ValueError('Invalid SSH host')
    args = argv if host == 'local' else ['ssh','-o','BatchMode=yes',host,shlex.join(argv)]
    return subprocess.run(args, check=check, capture_output=True, timeout=90)
def config(path):
    c=json.loads(path.read_text()); group=c['group']; assert group in GROUPS
    assert c['exclusive_reservation_ids'] and c['fresh_server_and_empty_disk_cache'] is True
    assert c['profile']==GROUPS[group][0], 'Profile differs from published group'
    assert c['tp']==len(c['nodes'])==(4 if group=='glm-tp4-extension' else 2)
    assert c['model'] and re.fullmatch(r'[a-zA-Z0-9_.-]+',c['arm']) and c['comparison_id']
    assert c['metadata']['context_limit']==GROUPS[group][1]
    assert c['metadata']['competing_traffic']=='none'
    assert c['metadata']['serving_image']==c['nodes'][0]['image_id']
    for n in c['nodes']:
        assert re.fullmatch(r'sha256:[0-9a-f]{64}',n['image_id'])
        for key in ('profile_sha256','manifest_sha256','binary_sha256'): assert re.fullmatch('[0-9a-f]{64}',n[key])
    return c

def snapshot(c,out,phase):
    records=[]
    for i,n in enumerate(c['nodes']):
        p=out/f'{phase}-rank{i}'; p.mkdir()
        raw=cmd(n,['docker','inspect',n['container']]).stdout; (p/'container.json').write_bytes(raw)
        info=json.loads(raw)[0]; assert info['State']['Running'] and info['Image']==n['image_id']
        for mount in info.get('Mounts',[]):
            assert not mount_overlaps_runtime(mount['Destination']), 'Runtime code overlay is not an official-image receipt'
        env=dict(x.split('=',1) for x in info['Config'].get('Env',[]) if '=' in x)
        key='SPARKGLM_PROFILE' if c['group'].startswith('glm') else 'SPARKQWEN_PROFILE'
        assert env.get(key)==c['profile'], f'{key} does not match expected profile'
        for k,v in c['required_launch_env'].items(): assert env.get(k)==v, 'Launch override mismatch: '+k
        assert (env.get('ATLAS_MTP_STEP_TRACE')=='1')==bool(c.get('step_trace_diagnostic',False)), 'Trace condition differs'
        assert not c.get('step_trace_diagnostic',False) or 'extension' in c['group']
        for key,path in [('profile',n['profile_path']),('manifest','/opt/atlas/source-manifest.json')]:
            raw=cmd(n,['docker','exec',n['container'],'cat',path]).stdout
            assert digest(raw)==n[key+'_sha256'], key+' identity mismatch'
            (p/(key+'.json')).write_bytes(raw)
        binary=cmd(n,['docker','exec',n['container'],'sha256sum','/usr/local/bin/spark']).stdout.decode().split()[0]
        assert binary==n['binary_sha256']
        (p/'image.json').write_bytes(cmd(n,['docker','image','inspect',n['image_id']]).stdout)
        log=cmd(n,['docker','logs',n['container']],check=False); (p/'container.log').write_bytes(log.stdout+log.stderr)
        clock=cmd(n,['systemctl','show','gpu-clock-cap.service','--property=ActiveState','--value']).stdout.decode().strip()
        (p/'nvidia-smi.txt').write_bytes(cmd(n,['nvidia-smi','-q']).stdout)
        records.append({'host':n['host'],'container':n['container'],'id':info['Id'],'started':info['State']['StartedAt'],'clock':clock})
    for endpoint in ('/health','/v1/models','/metrics'):
        with urllib.request.urlopen(c['url'].rstrip('/')+endpoint,timeout=30) as r:
            assert r.status==200; raw=r.read()
        (out/(phase+'-'+endpoint.strip('/').replace('/','_')+'.txt')).write_bytes(raw)
        if endpoint=='/v1/models': assert c['model'] in [m['id'] for m in json.loads(raw)['data']]
    dump(out/(phase+'-identity.json'),records)
    if phase=='after': require_inactive(records)
    return records

def commands(c,out):
    py=sys.executable; arm=c['arm']; base=c['url']; model=c['model']; group=c['group']
    rows=[]
    def add(name,argv,output,kind,minimum=1): rows.append({'name':name,'argv':[str(a) for a in argv], 'output':output,'kind':kind,'minimum_streams':minimum})
    rig=[py,H/'rigmark/bench.py','--base-url',base,'--model','auto','--metadata',out/'metadata.json',
         '--comparison-id',c['comparison_id'],'--extra-body','{"chat_template_kwargs":{"reasoning_effort":"low"}}']
    if 'extension' in group:
        add('step-probe',[py,ROOT/'step_probe.py',out/'config.json',out],'step-probe.json','step',6)
        if not c.get('step_trace_diagnostic',False):
            add('rig-extension',rig+['--runs','2','--prefill-runs','2','--prefill-depths','8192,32768,65536','--concurrency','1,2,3,4','--concurrency-runs','2','--label','glm-4x1m-extension','--output',out/'rig-extension.json'],'rig-extension.json','rig',38)
    elif group=='glm-main':
        common=rig+['--runs','2','--prefill-runs','2','--concurrency','1,2,3,4,5,6,8','--concurrency-runs','2']
        add('rig-code',common+['--label','atlas-code-full','--prefill-depths','8192,32768,65536','--output',out/'rig-code-full.json'],'rig-code-full.json','rig',76)
        add('rig-prose',common+['--label','atlas-prose-concurrency','--concurrency-workload','prose','--skip-prefill','--staggered','2,4,6,8','--staggered-runs','2','--staggered-depth','32768','--staggered-incumbent-tokens','1024','--staggered-arrival-tokens','256','--staggered-delay','1.0','--staggered-workload','prose','--output',out/'rig-prose.json'],'rig-prose.json','rig',64)
        add('kindling',[py,H/'kindling/bench/bench.py','run','--label',arm,'--out',out/'kindling.json'],'kindling.json','kindling',193)
    elif group=='glm-prefill':
        add('prefill',[py,H/'kindling/prefill.py','--base',base+'/v1','--model',model,'--sizes','32k,128k','--skip-thinking','--out-tokens','64'],None,'prefill',2)
    elif group=='qwen-main':
        add('rigmark',rig+['--runs','3','--prefill-runs','2','--prefill-depths','16384','--concurrency','1,2,4,8','--concurrency-runs','1','--label','rel-drafter','--output',out/'rigmark.json'],'rigmark.json','rig',28)
        add('sq',[py,H/'qwen/sq_bench.py',arm,'decode','prefill','conc','warm'],f'bench-{arm}.json','sq',59)
        add('sd',['node','--import',ROOT/'audit/fetch.mjs',H/'qwen/sd_bench.mjs',arm,'structured,prose,code,json','1,2,4,8'],f'sd-{arm}.json','sd',64)
        add('agentic',[py,H/'qwen/agentic_probe.py',arm,'4','5'],f'agentic-{arm}.json','agentic',20)
        for rep in range(1,4):
            name=f'field-{rep}'
            add(name,[py,H/'qwen/four_stream_video.py','capture','--base-url',base,'--model',model,'--output',out/(name+'.json'),'--streams','4','--max-tokens','400','--prompt-tokens','16384','--stagger-ms','1000','--prompt-style','field-guide','--prompt-salt',f"{c['comparison_id']}-rel-{rep}",'--timeout-s','600'],name+'.json','field',4)
    else:
        for name,con,depth in [('c1-16k',1,16384),('c1-32k',1,32768),('c2-16k',2,16384),('c2-32k',2,32768),('c4-16k',4,16384)]:
            add(name,[py,H/'qwen/staggered_openai.py','--base-url',base,'--model',model,'--concurrency',con,'--prompt-tokens',depth,'--exact-prompt-tokens','--prompt-salt',f"{c['comparison_id']}-{name}",'--output-tokens','400','--min-output-tokens','400','--stagger-ms','1000','--timeout-s','900'],name+'.json','matrix',con)
    return rows

def validate_result(row,out):
    audit=[json.loads(line) for line in (out/(row['name']+'.audit.jsonl')).read_text().splitlines()]
    assert len(audit)>=row['minimum_streams'] and all(r.get('ok') for r in audit), 'Missing/failed HTTP/SSE audit'
    kind=row['kind']
    if kind!='rig': assert len(audit)==row['minimum_streams'], 'Unexpected request count'
    d=json.loads((out/row['output']).read_text()) if row['output'] else None
    if kind=='rig':
        assert not d.get('error') and d['run']['finished_at']
        s=d['settings']; assert len(d['decode'])==3
        for v in d['decode'].values(): assert len(v['runs'])==s['runs'] and v['completion_gate']['passed']==v['completion_gate']['total']==s['runs']
        for depth in s['prefill_depths']:
            for mode in ('cold','warm_replay'): assert len(d['prefill'][str(depth)][mode]['runs'])==s['prefill_runs']
        for con in s['concurrency']:
            rounds=d['concurrency'][str(con)]['rounds']; assert len(rounds)==s['concurrency_runs']
            for r in rounds: assert len(r['streams'])==con
        for con in s['staggered']:
            for direction in ('decode_first','prefill_first'):
                value=d['staggered'][str(con)][direction]
                assert value['total_rounds']==s['staggered_runs'] and value['valid_rounds']==s['staggered_runs'], 'Invalid stagger overlap'
    elif kind=='step': assert len(d['rows'])==5
    elif kind=='kindling':
        assert len(d['runs'])==80 and set(d['summary'])=={'code','prose','structured','counting','mixed4','mixed8'}
        assert all(not r['problem'] for r in d['runs']), 'Kindling content checks failed'
    elif kind=='sq':
        assert {k:len(v) for k,v in d['cells'].items()}=={'decode':9,'prefill':8,'conc':8,'warm':12}
        assert all(r['out']==384 for r in d['cells']['decode'])
        assert all(r['tokens']==r['c']*256 for r in d['cells']['conc'])
    elif kind=='sd':
        assert len(d['waves'])==16 and all(len(w['perStream'])==w['c'] for w in d['waves'])
    elif kind=='agentic': assert len(d)==20 and all(r['ok'] for r in d), 'Agentic accuracy failed'
    elif kind=='field': assert sum(r['usage']['completion_tokens'] for r in audit)==1600
    elif kind=='matrix': assert d['summary']['successful']==row['minimum_streams']
    elif kind=='prefill': assert len(audit)==2
    return {'name':row['name'],'streams':len(audit),'passed':True}

def run(c,out):
    verify_package(out)
    require_inactive(json.loads((out/'post-uncap-clocks.json').read_text()))
    dump(out/'run-start.json',{'started_unix':time.time()})
    env=os.environ.copy(); env.update(PYTHONPATH=str(ROOT/'audit'), SQ_URL=c['url'],SQ_MODEL=c['model'],SQ_CONC='1,2,4,8',SD_MAX='400',
        GATE_URL=c['url'],GATE_MODEL=c['model'],SPARKDASH_DIR=str(H/'sparkDash'))
    passed=[]
    for row in commands(c,out):
        env['PERF_AUDIT']=str(out/(row['name']+'.audit.jsonl'))
        target=out/(row['output'] if row['kind']=='matrix' else row['name']+'.log')
        with target.open('wb') as log, (out/(row['name']+'.stderr.log')).open('wb') as err:
            p=subprocess.Popen(row['argv'],cwd=out,env=env,stdout=log,stderr=err,start_new_session=True)
            try:
                assert p.wait(timeout=5400)==0, row['name']+' exited nonzero'
            finally:
                if p.poll() is None:
                    os.killpg(p.pid,signal.SIGTERM)
                    try: p.wait(timeout=10)
                    except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); p.wait()
        passed.append(validate_result(row,out)); dump(out/'completed-cells.json',passed)
    after=snapshot(c,out,'after'); before=json.loads((out/'before-identity.json').read_text())
    assert [(r['id'],r['started']) for r in before]==[(r['id'],r['started']) for r in after], 'Container restarted during benchmark'
    verify_package(out)
    dump(out/'suite-passed.json',{'passed':True,'finished_unix':time.time(),'cells':passed})

def main():
    p=argparse.ArgumentParser(); p.add_argument('action',choices=['plan','prepare','uncap','restore','run']); p.add_argument('config',type=pathlib.Path); p.add_argument('out',type=pathlib.Path); a=p.parse_args()
    if not __debug__: raise RuntimeError('Do not run with Python optimization: verification assertions are required')
    c=config(a.config); out=a.out.resolve()
    if a.action=='plan': print(json.dumps(commands(c,out),indent=2)); return
    if a.action=='prepare':
        assert 'REPLACE_WITH' not in json.dumps(c) and all(n['image_id']!='sha256:'+'0'*64 for n in c['nodes']), 'Complete the exact identity config first'
        out.mkdir(parents=True,exist_ok=False); dump(out/'config.json',c); dump(out/'metadata.json',c['metadata']); dump(out/'commands.json',commands(c,out))
        verify_package(out,archive=True)
        records=snapshot(c,out,'before'); assert all(r['clock']=='active' for r in records), 'All clock cap services must initially be active'
    elif a.action=='uncap':
        assert (out/'before-identity.json').exists()
        for n in c['nodes']:
            cmd(n,['sudo','-n','/usr/bin/systemctl','stop','gpu-clock-cap.service'])
            assert cmd(n,['systemctl','is-active','gpu-clock-cap.service'],check=False).stdout.strip()==b'inactive'
        capture_uncapped_clocks(c,out)
    elif a.action=='restore':
        failures=[]
        for n in c['nodes']:
            try:
                cmd(n,['sudo','-n','/usr/bin/systemctl','start','gpu-clock-cap.service'])
                assert cmd(n,['systemctl','is-active','gpu-clock-cap.service']).stdout.strip()==b'active'
                (out/('restored-'+n['host'].replace(':','_')+'-nvidia-smi.txt')).write_bytes(cmd(n,['nvidia-smi','-q']).stdout)
            except Exception as exc: failures.append({'host':n['host'],'error':str(exc)})
        dump(out/'clock-restoration.json',{'restored':not failures,'failures':failures,'time':time.time()})
        assert not failures, 'Clock restoration failed; coordinator must restore immediately'
    else: run(c,out)

if __name__=='__main__':
    signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    main()
