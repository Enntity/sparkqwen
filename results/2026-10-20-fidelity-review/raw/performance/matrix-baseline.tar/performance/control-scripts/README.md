# Same-day release performance runner

Prepared only. No benchmarks, builds, container starts, clock changes, route changes, or publication have been run by this package's author.

Run one group on the serving leader after the coordinator reserves the complete hardware set through LLooM and launches the exact image with the original product `install/start-node.sh`. Use the same nodes/fabric, model checkpoint, drafter, launch overrides, comparison ID, and clock conditions for both arms. This runner never starts or stops model containers or changes routes. Copy this complete directory to a unique staging directory before invoking it.

1. Copy `config.example.json` to an arm/group-specific file. Fill immutable Docker image ID, container name, exact profile path/hash, embedded source-manifest hash, runtime binary hash, actual checkpoint/drafter metadata, active reservation IDs, and required launch environment. The example is intentionally rejected until filled. Use the fabric SSH address for each other rank; `local` is the leader.
2. Launch the designated profile, with a new empty disk prefix-cache directory for each arm/group. GLM's published TP2 settings are utilization 0.91, display carveout, KV sharding, and a 48 GB disk prefix cache. Qwen's published profiles use utilization 0.88; record their actual settings and any environment overrides. Required source/profile hashes are inputs, not auto-approved values learned from the live container. A mount replacing the binary or `/opt/atlas` is rejected.
3. Review commands without contacting any service: `python3 run.py plan CONFIG.json /absolute/new/receipt-dir`.
4. Only the coordinator invokes: `bash run-group.sh --uncap CONFIG.json /absolute/new/receipt-dir`.
5. A complete group requires both `suite-passed.json` and `clock-restoration.json` with `restored: true`. Preserve the entire directory on success or failure. Do not reuse its path. A benchmark failure does not delete partial evidence or trigger automatic retries.

`--uncap` is explicit. Before stopping any cap service, the runner confirms all participating services are active and takes identity/health/model/metrics/clock snapshots. Immediately after uncapping it saves each rank's service state and `nvidia-smi -q` output before starting work; the final snapshot must still show every cap service inactive. The shell trap restarts every participating cap service and verifies it after success, failure, INT, or TERM. SIGKILL, host loss, and power loss cannot run a shell trap; the coordinator remains responsible for restoring caps before releasing its leases. The package does not acquire/release leases or renew them: its reservation fields record the coordinator's active exclusive lease attestation.

## Matrix

| Group | Profile | Workload and repetitions | Planning time per arm, excluding model startup |
| --- | --- | --- | --- |
| `glm-main` | TP2 `8x128k` | Original RigMark code/decode/prefill/C1,2,3,4,5,6,8, two repetitions; original prose/staggered C2,4,6,8, two repetitions; kindling 16 single runs/workload, 8 mixed batches/workload, 2 warmups | 45–65 min |
| `glm-prefill` | TP2 `4x512k` | Original kindling calibrated 32K/128K cold prefill, 64 output-token cap, seed 1, one request per depth plus calibration | 3–8 min |
| `qwen-main` | TP2 `8x32k` | RigMark 3 decode/2 prefill/1 concurrency repetitions; sq decode/prefill/conc/warm unchanged; sparkDash 4 types × C1,2,4,8 with each type's 32-token warmup; agentic 4 conversations × 5 turns; field guide 3 × C4 | 15–30 min |
| `qwen-matrix` | TP2 `8x262k` | Original five G3 cells: C1/C2 at 16K/32K and C4 at 16K; exact prompts, 400 forced tokens, 1000 ms stagger, one run each | 3–8 min |
| `glm-pair-extension` | TP2 `4x1m` | Separate C1 step probe and RigMark code/decode/prefill/C1,2,3,4 with two repetitions | 7–15 min |
| `glm-tp4-extension` | TP4 `4x1m-tp4` | Same extension prompts/repetitions as TP2 | 7–15 min |

Historical raw receipts measured GLM code 394.47 s and prose 1457.52 s; Qwen RigMark took 162.90 s. Remaining estimates allow for kindling/streaming/prefill variation. Budget roughly 2.5–4 hours for both published TP2 arms, plus profile restarts, image loading, and separate TP4 comparison. No quality evaluation is duplicated here.

The TP4 profile supports four sequences. Its extension is not a historical TP4 baseline and does not relabel the published C8 workload. `step_probe.py` preserves the original one “Say hi” warmup plus five 512-token-cap prose requests. The same deterministic 12-hex run tags are used on the TP2/TP4 arms; the old script used UUID tags. It saves per-request log slices, requires one attributable `Done:` line, and reports `1000 * tok_step / server_tok_s` as **derived step milliseconds**, alongside accepted tok/s. The approximately 26 ms chain goal applies to this separately labeled measure. It is not a direct GPU kernel timer.

Optional trace diagnostic: set `step_trace_diagnostic: true` only on a separate extension config and have the coordinator launch with `ATLAS_MTP_STEP_TRACE=1`. That runs just the six-request step probe and additionally preserves/parses raw `MTP STEP` durations, with `(dur-pf)/1000` and explicit steady-state filtering. Never use a traced run as the normal published performance arm. Ordinary groups reject a trace-enabled container.

## Baseline identity and dependencies

GLM's previous published image is `ghcr.io/enntity/atlas-sparkglm@sha256:0b91fd790afb2ee3aa5a7f39a0bc5a90db05751436ae7810e00f129c36ebbb7b`. Resolve and record its platform-local Docker image ID for every node. Latest public-source Qwen FP4-Local/vision baseline is the retained local `ghcr.io/enntity/atlas-sparkqwen:3b2deea3d187`, image ID `sha256:44d739d076fc1b2d2048ca0c471cd9a164f11110a65381b7df4354b21b2334ce` on 01. Its GHCR tag returned 404 during the audit, with no local RepoDigests. Do not claim it was registry-published, and do not substitute the old b151fbe840a1 NVFP4 checkpoint image for this matched FP4-Local baseline. Candidate identities must be supplied after final qualification/build.

Dependencies: Python 3 stdlib, Node with native fetch/TransformStream and `--import` support (Node 20+), Docker CLI, NVIDIA tools, SSH over the chosen fabric, and passwordless permission for the existing `/usr/bin/systemctl stop/start gpu-clock-cap.service`. The exact image, profile, weights, drafter, empty-cache launch, healthy endpoint, exclusive LLooM reservation, and settled uncapped clocks are coordinator prerequisites. This package neither provisions nor downloads them.

## Evidence and protocol preservation

`harness-sha256.json` pins the frozen sources. `runner-sha256.json` pins the control scripts and companion files; preparation verifies both manifests, copies both to the receipts, and saves the verified control files under `control-scripts/`. The runner rechecks both sets against the saved manifests before and after the workload. RigMark is an unmodified git archive at `40fabcaf6e963ac27ab347f61d54a225dbd07419`; its source fingerprint is `71cf88ee30ff5e0c976ad5b1d8221af9115447a690039ac9aa020a85015fe300`, matching published receipts. Qwen scripts come from the public product checkout; the exact remote release wrapper, matrix driver, field-guide driver, sparkDash prompts, and kindling code were copied read-only from 01. `remote-provenance.txt` records the prompt checkout revision and MIT license. Original release wrappers are evidence only and must not be executed: they contain old build/deployment commands.

The original matrix driver hardcodes a home-directory driver path and can return success after child failure. `run.py` reproduces its five argv lists against the frozen driver, checks every child exit, and validates every cell. No workload was removed. GLM's second RigMark invocation retains its repeated decode measurements. Same-day comparison IDs/salts are shared between arms; original release scripts used time-based field-guide salts.

The original inference scripts are unchanged. Scoped Python `sitecustomize` and Node fetch wrappers retain the received SSE bytes and validate completion at EOF: HTTP 200, no SSE error, `[DONE]`, finish reason, positive usage, and any requested forced output length. They write request-body hashes and usage receipts, and fail the process or final audit if the original harness catches the error. This adds a small common client-side audit cost; use the wrappers on both same-day arms. The final suite checks expected repetition/cell counts, RigMark completion gates and stagger overlap, kindling content checks, and agentic accuracy. It never treats HTTP 200 alone as a passing measurement.

Offline validation: `python3 test_offline.py` (15 tests), Python compilation, shell syntax, Node syntax and two in-memory Node stream fixtures, and all three historical RigMark receipt shapes passed. Hardware execution remains deliberately untested.
